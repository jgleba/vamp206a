    <!-- Page Content -->
    <div class="container" id="about" style="padding-top: 70px;" >

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>about</h1>
                <p class="lead">about Complete with pre-defined file paths that you won't have to change!</p>
                <ul class="list-unstyled">
                    <li>Bootstrap v3.3.1</li>
                    <li>jQuery v1.11.1</li>
                </ul>
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->
    

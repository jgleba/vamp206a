    <!-- Page Content -->
    <div class="container" id="about" >
        
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>A Bootstrap Starter Template</h1>
                <p class="lead">Complete with ..</p>
                <ul class="list-unstyled">
                    <li>Bootstrap v3.3.x</li>
                    <li>jQuery v1.11.1</li>
                    <li>This is made with www.startbootstrap.com 'bare' template and a few .php files to pull the pieces together {include} into pages with a header nav body and footer.</li>
                    <li>David Gleba 2015-07-07, 2015-07-19-rev14</li>
                </ul>
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->
    

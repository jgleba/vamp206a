    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>pag2</h1>
                <p class="lead">2</p>
                <ul class="list-unstyled">
                    <li>a</li>
                    <li>b</li>
                </ul>
            </div>
        </div>
        <!-- /.row -->
        
       
    </div>
    <!-- /.container -->
    

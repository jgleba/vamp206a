 
   <!-- whitespace under the section -->
   <div> <h1 style="line-height: 100%;">  &nbsp  </h1> </div>

<div style='background-color:grey; color:white; text-align: center;'> --- 2015 --- </div> 
<!-- <div style='background-color:grey;'> &nbsp </div>  -->

   <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>

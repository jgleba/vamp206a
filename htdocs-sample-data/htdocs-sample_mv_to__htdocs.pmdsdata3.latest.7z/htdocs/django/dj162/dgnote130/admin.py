from django.contrib import admin

# Register your models here.

from dgnote130.models import NteNote

admin.site.register(NteNote)